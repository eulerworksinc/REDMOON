Using PSDRO:
1. Place the files PSDRO.EXE and NMCLIB04.DLL in a single folder.  
Make sure you use the version of NMCLIB04.DLL included in SD_CNC.ZIP.

2. Set up your controllers as described in the document SD_CNC.PDF.
See Section 6.0 of SD_CNC.PDF for instructions on using PSDRO.EXE.

